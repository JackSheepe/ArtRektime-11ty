---
name: Ресторан Крепость
description: Фигурный световой короб
img: /assets/img/pic/lightbox3.png
alt: Ресторан Крепость Фигурный световой короб
---
