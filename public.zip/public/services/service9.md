---
title: Жидкий Акрил
link: /fluidacryl/index.html
image: /assets/img/icons/acrylicon.svg
alt: иконка Жидкого Акрила
---
