---
title: Гибкий Неон
link: /neon/index.html
image: /assets/img/icons/neonicon.svg
alt: иконка гибкого неона
---
