---
title: Размещение

  рекламы
link: /adplacement/index.html
image: /assets/img/icons/placement.png
alt: иконка баннера
---
