---
title: Широкоформатная

  печать
link: /wideformat/index.html
image: /assets/img/icons/wideFormat.png
---
