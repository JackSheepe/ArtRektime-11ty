---
title: Фрезерная

  резка с ЧПУ
link: /stanok/index.html
image: /assets/img/icons/stanok.png
alt: иконка станка
---
