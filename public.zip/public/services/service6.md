---
title: Бегущие строки и
  LED экраны
link: /led/index.html
image: /assets/img/icons/led.png
alt: иконка LED
---
