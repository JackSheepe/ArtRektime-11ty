---
name: Империя
description: Вывеска световая, объемные буквы, неон
img: /assets/img/pic/viveski11.png
alt: Империя Вывеска световая, объемные буквы, неон
---
