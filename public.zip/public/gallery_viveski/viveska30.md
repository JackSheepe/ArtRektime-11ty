---
name: Магазин Фея
description: Световые объемные буквы, фигурный световой короб
img: /assets/img/pic/viveski30.png
alt: Магазин Фея
---
