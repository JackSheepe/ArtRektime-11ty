---
name: Магазин Березка
description: Объемная световая вывеска
img: /assets/img/pic/viveski19.png
alt: Магазин Березка Объемная световая вывеска
---
