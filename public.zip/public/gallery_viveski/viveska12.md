---
name: Империя
description: Вывеска световая, объемные буквы, неон
img: /assets/img/pic/viveski12.png
alt: Империя Вывеска световая, объемные буквы, неон
---
