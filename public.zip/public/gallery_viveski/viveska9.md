---
name: Grill & Bar Amsterdam
description: Световые объемные буквы из светорассеющего акрилового стекла
img: /assets/img/pic/viveski9.png
alt: Grill & Bar Amsterdam Световые объемные буквы из светорассеющего акрилового стекла
---
