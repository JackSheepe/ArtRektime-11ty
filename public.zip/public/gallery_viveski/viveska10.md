---
name: Лада
description: Вывеска световая
img: /assets/img/pic/viveski10.png
alt: Лада Вывеска световая
---
