---
title: Размещение рекламы
layout: ./layouts/base.html
portfolioListLitle: Размещение рекламы
список_продукции:
  - видеореклама
links:
  - https://videoAds.html
---

<h1>Рекламные ролики в автобусах</h1>

<div class="video__flex">

<iframe width="433" height="250" src="https://www.youtube.com/embed/kfA-xYVYcGI" title="Клуб единоборств Добрыня г. Белово" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<iframe width="434" height="250" src="https://www.youtube.com/embed/XDAE4XW0ZkQ" title="Радостный Мир , г. Белово" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<iframe width="434" height="250" src="https://www.youtube.com/embed/Zs5_0guv5nU" title="Промэкс" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<iframe width="434" height="250" src="https://www.youtube.com/embed/8LS-qxH5zCQ" title="Правовая группа Любич и партнеры" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<iframe width="434" height="250" src="https://www.youtube.com/embed/CtY1mffKip8" title="Беловский трикотаж" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<iframe width="434" height="250" src="https://www.youtube.com/embed/NuX_HcwWrGU" title="Самоцветы г. Белово" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

</div>
