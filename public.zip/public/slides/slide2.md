---
image: assets/img/pic/banner2.png
alt: баннер акция 1м в квадрате от 170 рублей
---
