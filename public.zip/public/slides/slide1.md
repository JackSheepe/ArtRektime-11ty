---
image: assets/img/pic/banner1.gif
alt: баннер реклама на маршрутном телевидении
---
